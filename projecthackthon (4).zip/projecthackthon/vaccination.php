<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projecthackthon";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get child ID (For now, using static ID 1. You can change it dynamically based on login)
$child_id = 1;

// Fetch vaccination details
$sql = "SELECT * FROM vaccination_schedule WHERE child_id = $child_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccination Tracker</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="bg-success text-white py-4 text-center">
        <h1>Vaccination Tracker</h1>
        <a href="home.html" class="btn btn-light">Back to Home</a>
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Child’s Vaccination Schedule</h2>
        <table class="table table-bordered mt-4">
            <thead class="thead-dark">
                <tr>
                    <th>Vaccine Name</th>
                    <th>Age Group</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['vaccine_name']; ?></td>
                    <td><?php echo $row['age_group']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td>
                        <?php if ($row['status'] == 'Pending') { ?>
                            <a href="update_status.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Mark as Completed</a>
                        <?php } else { ?>
                            <span class="text-success">Completed</span>
                        <?php } ?>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <footer class="bg-dark text-white text-center py-4">
        <p>&copy; 2025 Parent & Child Healthcare Platform</p>
    </footer>
</body>
</html>

<?php $conn->close(); ?>
